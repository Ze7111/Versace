import os, sys
with open(os.path.expanduser('~') + os.sep + "Versace" + os.sep + "ABS-Path.path", "wb") as f:
    f.write("DO NOT EDIT/DELETE THIS FILE IT IS MANDOTORY FOR VERSACE TO RUN\n".encode("utf-8"))
    f.write(sys.executable.encode("utf-32-le"))